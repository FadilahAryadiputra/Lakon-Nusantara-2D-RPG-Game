using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class MovementJoystick : MonoBehaviour
{
    public PlayerController player;
    public GameObject joystick;
    public GameObject  joystickBG;
    public Vector2 joystickVec;
    private Vector2 joystickTouchPos;
    private Vector2 joystickOriginalPos;
    private float joystickRadius;
    [SerializeField]
    private float joystickRadiusDivider = 1;

    // Start is called before the first frame update
    void Start()
    {
        joystickOriginalPos= joystickBG.transform.position;
        joystickRadius = joystickBG.GetComponent<RectTransform>().sizeDelta.y / joystickRadiusDivider;
    }

    public void PointerDown()
    {
        joystick.transform.position = Input.mousePosition;
        joystickBG.transform.position = Input.mousePosition;
        joystickTouchPos = Input.mousePosition;
    }

    public void Drag(BaseEventData baseEventData)
    {
        PointerEventData pointerEventData = baseEventData as PointerEventData;
        Vector2 dragPos = pointerEventData.position;
        joystickVec = (dragPos - joystickTouchPos).normalized;
        player.movementInput = joystickVec;
        if (player.defeated != true && player.moveSuccess == true) {
            player.dustParticle.Play();
            AudioManager.instance.PlaySFXLoop(player.PlayerWalkSFX);
        }

        float joystickDist = Vector2.Distance(dragPos, joystickTouchPos);

        if(joystickDist < joystickRadius)
        {
            joystick.transform.position = joystickTouchPos + joystickVec * joystickDist;
        }
        else
        {
            joystick.transform.position = joystickTouchPos + joystickVec * joystickRadius;
        }
    }

    public void PointerUp()
    {
        joystickVec = Vector2.zero;
        joystick.transform.position = joystickOriginalPos;
        joystickBG.transform.position = joystickOriginalPos;
        player.movementInput = joystickVec;
        player.dustParticle.Stop();
        AudioManager.instance.StopSFXLoop(player.PlayerWalkSFX);
    }
}
