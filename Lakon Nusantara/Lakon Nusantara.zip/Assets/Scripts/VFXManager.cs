using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VFXManager : MonoBehaviour
{
    void Destroy()
    {
        Destroy(gameObject);
    }
}
