using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class QuestTimer
{
    public bool TimerOn = false;
    public float TimeLeft;
    public bool TimeIsUp = false;
}
