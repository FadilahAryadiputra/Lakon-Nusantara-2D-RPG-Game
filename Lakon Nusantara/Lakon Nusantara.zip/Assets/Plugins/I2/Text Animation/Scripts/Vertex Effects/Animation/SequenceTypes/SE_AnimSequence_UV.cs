﻿using UnityEngine;
using System.Collections;
using System;
using System.Xml.Serialization;
#if UNITY_EDITOR
using UnityEditor;
#endif


//namespace I2.TextAnimation
//{}
