using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class RestrictedAreaController : MonoBehaviour
{
    public AIPath AIPath;
    public Transform targetDestination;

    public Transform objectives01Pos;

    private void Update()
    {
    }

    private void OnTriggerEnter2D(Collider2D other)
	{
		if(other.tag == "Player") 
		{

        }
    }
}
